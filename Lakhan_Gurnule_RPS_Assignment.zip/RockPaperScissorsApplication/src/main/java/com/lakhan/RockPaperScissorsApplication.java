package com.lakhan;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class RockPaperScissorsApplication {

	private final List<String> MOVES = Arrays.asList("Rock", "Paper", "Scissors");
    private final Random random = new Random();

    @PostMapping("/play")
    public ResponseEntity<String> playGame(@RequestBody String playerMove) {
        // Generate the computer's move randomly
        String computerMove = generateRandomMove();

        // Determine the winner based on the moves
        String result = determineWinner(playerMove, computerMove);

        // Return the winner as a response
        return ResponseEntity.ok(result);
    }

    private String generateRandomMove() {
        int randomIndex = random.nextInt(MOVES.size());
        return MOVES.get(randomIndex);
    }

    private String determineWinner(String playerMove, String computerMove) {
        if (playerMove.equals(computerMove)) {
            return "It is a tie";
        } else if (playerMove.equals("Rock")) {
            if (computerMove.equals("Scissors")) {
                return "Player wins";
            } else {
                return "Computer wins";
            }
        } else if (playerMove.equals("Paper")) {
            if (computerMove.equals("Rock")) {
                return "Player wins";
            } else {
                return "Computer wins";
            }
        } else if (playerMove.equals("Scissors")) {
            if (computerMove.equals("Paper")) {
                return "Player wins";
            } else {
                return "Computer wins";
            }
        } else {
            return "Invalid move";
        }
    }

  
	public static void main(String[] args) {
		SpringApplication.run(RockPaperScissorsApplication.class, args);
	}

}
